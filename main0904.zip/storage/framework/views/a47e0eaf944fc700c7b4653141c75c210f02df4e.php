<?php $__env->startComponent('mail::message'); ?>
# Verify New Email Address

Please click the button below to verify your new email address.

<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Verify New Email Address
<?php echo $__env->renderComponent(); ?>

If you did not update your email address, no further action is required.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/vendor/verify-new-email/verifyNewEmail.blade.php ENDPATH**/ ?>