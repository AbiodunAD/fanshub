

<?php $__env->startSection('title'); ?>
 Pages - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <h1>Information Pages</h1> <a href="<?php echo e(route('page.create')); ?>" type="button" class="btn btn-primary float-right addnewbtn">Add New Page</a>
 <div id="dashbox-slim">

    <?php echo $__env->make('includes.message-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>Title</th>
                    <th>Excerpt</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                       
                <tr>                    
                    <td><a href="<?php echo e(route('page.show', $page->slug)); ?>" target="_blank"><?php echo e($page->title); ?></a></td>
                    <td><?php echo e($page->excerpt); ?></td>
                    <td>
                        <a href="<?php echo e(route('page.edit', $page->id)); ?>" class="btn btn-success" style="width:100%;">Edit</i></a>
                        <br>
                        <div id="userdelete">
                            <a href="#" onclick="cDelete()" id="fandelete">
                            <button class="btn btn-danger" style="width:100%;">Delete</button>
                            </a>
                            <div id="confirm-dele">
                                <p>Are you sure you want to delete this Page?</p>
                                <form action="<?php echo e(route('page.delete', $page->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger" style="width:100%;">Yes Delete</button>
                                    <span class="btn btn-success" style="width:100%;" onclick="cDelete()">Cancel Delete</span>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/pages.blade.php ENDPATH**/ ?>