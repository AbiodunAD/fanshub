

<?php $__env->startSection('title'); ?>
 Fans - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <h1>All Fans</h1>  <a href="<?php echo e(route('fan.create')); ?>" type="button" class="btn btn-primary float-right addnewbtn">Add New Fan</a>
 <div id="dashbox-slim">
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>


    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Profession</th>
                    <th class="tabimg">Profile Photo</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                       
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    
                    <td><a href="<?php echo e(route('fansprofile', $user->first_name)); ?>"><?php echo e($user->first_name); ?></a></td>
                    <td><a href="<?php echo e(route('fansprofile', $user->first_name)); ?>"><?php echo e($user->last_name); ?></a></td>
                    
                    <td><?php echo e($user->profession); ?></td>
                    <td class="tabimg">
                        <img src="<?php echo e($user->profilephoto ? asset( 'storage/media/' . $user->profilephoto ) : asset( 'img/iuser.png' )); ?>">
                    </td>                
                    <td><?php if($user->status == 0): ?> Inactive <?php else: ?> Active <?php endif; ?></td>
                    <td>
                        <a href="<?php echo e(route('status', $user->id)); ?>" class="btn btn-primary"style="width:100%;">Change Status</a>
                        <br>
                        <a href="<?php echo e(route('fan.edit', $user->id)); ?>" class="btn btn-success" style="width:100%;">Edit</i></a>
                        <br>
                        <div id="userdelete">
                            <a href="#" onclick="cDelete()" id="fandelete">
                            <button class="btn btn-danger" style="width:100%;">Delete</button>
                            </a>
                            <div id="confirm-dele">
                                <p>Are you sure you want to delete this Fan?</p>
                                <form action="<?php echo e(route('fan.delete', $user->id)); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" class="btn btn-danger" style="width:100%;">Yes Delete</button>
                                    <span class="btn btn-success" style="width:100%;" onclick="cDelete()">Cancel Delete</span>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/fans.blade.php ENDPATH**/ ?>