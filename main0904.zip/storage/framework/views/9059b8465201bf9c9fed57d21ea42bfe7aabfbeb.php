

<?php $__env->startSection('title'); ?>
 Creat New Fan - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Creat a New Fan's Account</h1>
<div id="dashbox">
    <div class="log-form">

        <form method="post" action="<?php echo e(route('fan.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div>
                <label>Enter Fan's First name:</label>
                <input id="first_name" name="first_name" type="text" placeholder="First Name:" required autofocus />
            </div>

            <div>
                <label>Enter Fan's Last Name:</label>
                <input id="last_name" name="last_name" type="text" placeholder="Last Name:" required autofocus />
            </div>

            <div>
                <label>Slect Fan's Profession:</label>
                <select name="profession" placeholder="Select Profession:">
                    <option>Artist</option>
                    <option>Musician</option>
                    <option>Creator</option>
                    <option>Promoter</option>
                    <option>Photographer</option>
                    <option>Video Maker</option>
                    <option>Dancer</option>
                    <option>Producer</option>
                    <option>Location Manager</option>
                    <option>Dress Stylist</option>
                    <option>Nail Artiste</option>
                    <option>Hair Stylist</option>
                    <option>Artiste Manager</option>
                    <option>Studio Owner</option>
                    <option>Songwriter</option>
                    <option>Journalist</option>
                    <option>Radio DJ</option>
                    <option>Event DJ</option>
                    <option>TV Programmer</option>
                    <option>Master of Ceremony</option>
                    <option>Entertainer</option>
                    <option>Influencer</option>
                    <option>Others</option>
                </select>
            </div>

            

            <div>
                <label>Enter Fan's Email:</label>
                <input id="email" name="email" type="email" placeholder="Email Address:" />
            </div>

            <div>
                <label>Enter Fan's Password:</label>
                <input id="password" placeholder="Password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <p>&nbsp;</p>
            <div class="flex items-center gap-4">
                <button type="submit">Save Profile</button>
            </div>
            <button><a href="<?php echo e(route('fans.list')); ?>">Cancel</a></button>
        </form>
        
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/create-fan.blade.php ENDPATH**/ ?>