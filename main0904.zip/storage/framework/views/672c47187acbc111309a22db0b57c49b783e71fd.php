<!-- Edit Modal -->
<div class="modal fade" id="editpostcard<?php echo e($postcard->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h3 class="modal-title fs-5" id="exampleModalLabel">Edit Post</h3>
        </div>
        <div class="modal-body postcard">
            <input type="hidden" name="postcard_id" value="">
            <form method="POST" action="<?php echo e(route('update.postcard', $postcard->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>
                <div>
                    <textarea id="post" class="scroll" style="resize: none;color: #000;border: 0;min-height:150px;" name="post"><?php echo e($postcard->post); ?></textarea>
                </div> 

                <div class="modal-foot">
                    
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
                </div>
            </form>  
        </div> 
    </div>
    </div>
</div>

<!-- Comment Modal -->
<div class="modal fade" id="postcardcomments<?php echo e($postcard->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body postcard">
                <div class="fullcol"><div class="modal-close" data-bs-dismiss="modal">x</div></div>
                
                <div class="pop-comm-left">
                    <a href="<?php echo e(route('fanprofile', $postcard->user->first_name)); ?>">
                    <img src="<?php echo e($postcard->user->profilephoto ? asset( 'storage/media/' . $postcard->user->profilephoto ) : asset('img/iuser.png')); ?>">
                    </a>
                </div>
                <div class="pop-comm-right">
                    <a href="<?php echo e(route('fanprofile', $postcard->user->first_name)); ?>">
                    <p class="oto"><span><?php echo e($postcard->user->first_name); ?> <?php echo e($postcard->user->last_name); ?></span> <span class="po-time"><?php echo e($postcard->getTimeAgo($postcard->created_at)); ?></span></p>
                    </a>
                    <p class="opo"><?php echo e($postcard->post); ?></p>
                </div>
                
                <hr>
                
                
                <?php $__currentLoopData = $postcard->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="pop-comm-right" id="po-comment">
                    <div class="pop-comm-box">
                        <div class="pop-comm-left2">
                            <a href="<?php echo e(route('fanprofile', $postcard->user->first_name)); ?>">
                            <img src="<?php echo e($comment->user->profilephoto ? asset( 'storage/media/' . $comment->user->profilephoto ) : asset('img/iuser.png')); ?>">
                            </a>
                        </div>
                        <div class="pop-comm-right">
                            <a href="<?php echo e(route('fanprofile', $comment->user->first_name)); ?>">
                            <p class="oto"><span><?php echo e($comment->user->first_name); ?> <?php echo e($comment->user->last_name); ?></span> <span class="po-time"><?php echo e($comment->getTimeAgo($comment->created_at)); ?></span></p>
                            </a>
                            <p class="opo"><?php echo e($comment->body); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </div> 
            <p>&nbsp;</p>
        </div>
    </div>
</div>


<!-- Share Modal -->
<div class="modal fade" id="postcardshare<?php echo e($postcard->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-body postcard">
                <div class="fullcol"><div class="modal-close" data-bs-dismiss="modal">x</div></div>

                <div class="pop-comm-left">
                    <a href="<?php echo e(route('fanprofile', $postcard->user->first_name)); ?>">
                    <img src="<?php echo e($postcard->user->profilephoto ? asset( 'storage/media/' . $postcard->user->profilephoto ) : asset('img/iuser.png')); ?>">
                    </a>
                </div>
                <div class="pop-comm-right">
                    <a href="<?php echo e(route('fanprofile', $postcard->user->first_name)); ?>">
                    <p class="oto"><span><?php echo e($postcard->user->first_name); ?> <?php echo e($postcard->user->last_name); ?></span> <span class="po-time"><?php echo e($postcard->getTimeAgo($postcard->created_at)); ?></span></p>
                    </a>
                    <p class="opo"><?php echo e($postcard->post); ?></p>
                </div>
                
                <hr>

                    <div id="share-links">
                    <li>Share this:</li> <?php echo $contents = \Share::currentPage($postcard->post)
                        ->facebook()
                        ->twitter()
                        ->linkedin('Extra linkedin summary can be passed here')
                        ->whatsapp(); ?>

                    </div>
            </div>
            <p>&nbsp;</p>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/includes/modalcard.blade.php ENDPATH**/ ?>