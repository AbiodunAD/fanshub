<div id="postshared">
    <div class="mainpost">
        <p><?php echo e($postcard->post); ?></p>
        <div class="po-mdi">
            <?php if($postcard->postvideo): ?>{
                <p>
                    <video width="100%" height="240" controls>
                        <source src="<?php echo e($postcard->postvideo ? asset( 'storage/media/' . $postcard->postvideo ) : ''); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                    </video>
                </p>

            } <?php elseif($postcard->postimage): ?>{
                <p><img src="<?php echo e($postcard->postimage ? asset( 'storage/media/' . $postcard->postimage ) : ''); ?>"></p>
            }
            <?php endif; ?>
        </div>
    </div>
    <div class="mp-icons">
        <div class="mpi-c" data-bs-toggle="modal" data-bs-target="#postcardcomments<?php echo e($postcard->id); ?>" data-id="<?php echo e($postcard->id); ?>" id="postcardComment">
            <a href="#">
                <span class="ic-tx">
                    <i class="fa-regular fa-comment"></i> <?php echo e($postcard->comments()->count()); ?>    
                </span>
            </a>
        </div> 

        <div class="mpi-l"> 
            <a href="#">                   
                <span class="ic-tx like--btn" > 
                <i class="fa-regular fa-thumbs-up"></i> <?php echo e($postcard->like()->count()); ?>

                </span>
            </a>
        </div>

        <?php if(Auth::user() == $postcard->user): ?>
            <div class="mpi-e" data-bs-toggle="modal" data-bs-target="#editpostcard<?php echo e($postcard->id); ?>" data-id="<?php echo e($postcard->id); ?>" id="editPostcard">
                <a href="#">
                    <span class="ic-tx">
                        <i class="fa-regular fa-edit"></i> Edit
                    </span>
                </a>
            </div>
            <div class="mpi-d">
                <span>
                    <a href="<?php echo e(route('delete.postcard', ['postcard_id' => $postcard->id])); ?>">
                        <span class="ic-tx">
                           <i class="fa-regular fa-trash-o"></i> Delete
                        </span>
                    </a>
                </span>
            </div>
        <?php endif; ?>
        <div class="mpi-date"><span><?php echo e($postcard->getTimeAgo($postcard->created_at)); ?></span></div>
    </div>
    <div class="comment-bx">
        <form method="post" action="<?php echo e(route('postcard.comment', $postcard->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="ps-tx">
                <input type="hidden" name="postcard_id" value="<?php echo e($postcard->id); ?>" />
                <textarea id="comment" class="scroll" style="resize: none" name="body" placeholder="add comment" required></textarea>
                <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($body); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> 
            
            <button class="ps-send"><i class="fa-regular fa-send-o"></i> </button>
        </form>  
    </div>
</div><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/includes/postshared.blade.php ENDPATH**/ ?>