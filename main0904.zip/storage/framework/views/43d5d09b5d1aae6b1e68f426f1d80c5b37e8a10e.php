

<?php $__env->startSection('title'); ?>
    afribeats® - The Fanshub of AMFW NETWORK
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="s-container" class="remove-on-mobile">&nbsp;</div>
<div id="s-container">&nbsp;</div>


<div id="wrap">
    <div class="placeholder">
        <div class="spos-box">
			<div id="postprofile">
                <div class="ppimg">
                    <img src="<?php echo e($postcard->user->profilephoto ? asset( 'storage/media/' . $postcard->user->profilephoto ) : asset( 'img/iuser.png' )); ?>">
                </div>
                <div class="ppdetail">
                    <p class="ppu-name"><?php echo e($postcard->user->first_name); ?> <?php echo e($postcard->user->last_name); ?></p>
                    <p class="ppu-aliase"><?php echo e($postcard->user->profession); ?></p>
                </div>
            </div>
            <?php echo $__env->make('includes.pscard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="btn-white"><a href="<?php echo e(route('login')); ?>">Login or Register to see more posts</a></div>
		</div>
	</div>
</div>

<div id="s-container" class="remove-on-mobile">&nbsp;</div>


<div id="s-container">
    <div id="wrap">
       
        <div class="log-form">
            <h3>MEMBERSHIP IS FREE</h3>
            <p style="margin-bottom: 0;">Supported only by Donations & Sponsorship</p>
            <p>Donate to, or sponsor afribeats "Talent Support Revolution" today and get a STAR up on the success podium</p>
            <div class="footer"><p class="btn-grey"><a href="https://www.paypal.com/donate/?hosted_button_id=42UQ84BW4GWVG" target="_blank">Donate</a></p></div>
        </div>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            $(document).on('click', '.mp-icons', function(e){
                e.preventDefault();
                alert('You must login to interact with this post');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/singlepostcard.blade.php ENDPATH**/ ?>