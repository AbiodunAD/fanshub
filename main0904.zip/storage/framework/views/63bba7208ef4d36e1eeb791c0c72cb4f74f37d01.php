<div class="row">
    
    <div class="col-sm-10">
        <?php echo e($comment->body); ?>

        <footer class="blockquote-footer">
                    <span>
                        <?php echo e(\Carbon\Carbon::parse($comment->created_at)->diffForHumans()); ?>

                    </span>
        </footer>

    </div>
</div><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/comment.blade.php ENDPATH**/ ?>