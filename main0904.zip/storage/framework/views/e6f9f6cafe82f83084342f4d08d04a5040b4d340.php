<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
		<meta name="viewport" content="width=device-width">
		<title><?php echo $__env->yieldContent('title'); ?></title>
		<link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('stylesheet.css')); ?>">
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('slider.css')); ?>">
		<!-- Scripts -->
		<script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
		<!-- Scripts -->
		<script src="https://kit.fontawesome.com/22d44955ad.js" crossorigin="anonymous"></script>
		
	</head>

    <body>
		<div id="header-section">
			<div id="wrap">
				
					<div class="header-logo">
						<a href="<?php echo e(route('welcome')); ?>"><img src="<?php echo e(asset('img/logo2.png')); ?>"></a>
					</div>
					<div class="header-menu header">
						<div class="header">
							<ul class="menu">
								
								<?php if(auth()->guard()->guest()): ?>

									<?php if(Route::has('login')): ?>
										<li class="nav-item">
											<a class="nav-link" href="<?php echo e(route('login')); ?>">Signup/Login</a>
										</li>
									<?php endif; ?>

																	
									<?php else: ?>
										<?php if(Auth::user()): ?>
										<li class="nav-item">
											<a class="nav-link" href="<?php echo e(route('home')); ?>">My Account</a>
										</li>
										<?php endif; ?>
								<?php endif; ?>    
                            </ul>
						</div>
					</div>


					<?php if(auth()->guard()->guest()): ?>
						<?php if(Route::has('login')): ?>
						<a href="<?php echo e(route('login')); ?>">
						<div class="show-on-small" id="small-log">
							<img src="<?php echo e(asset('img/iuser.png')); ?>">
						</div>
						</a>
						<?php endif; ?>

						<?php else: ?>
							<?php if(Auth::user()): ?>
								<a href="<?php echo e(route('home')); ?>">	
								<div class="show-on-small" id="small-log" style="background-image:url('<?php echo e(Auth::user()->profilephoto ? asset( 'storage/media/' . $user->profilephoto ) : asset('img/iuser.png')); ?>');background-size: cover;
									background-repeat: no-repeat; ">
									&nbsp;
								</div>	
								</a>
							<?php endif; ?>
					<?php endif; ?>


				
			</div>
		</div>

		<div id="foo-bar">
			<div id="wrap">
			  	<ul class="menu">
					<li><a href="<?php echo e(route('welcome')); ?>">
						<span><img src="<?php echo e(asset('img/ihome.png')); ?>"></span>
						<span>Home</span>
					</a></li>
					
					<li><a href="<?php echo e(route('contact')); ?>">
						<span><img src="<?php echo e(asset('img/icontact.png')); ?>"></span>
						<span>Contacts</span>
					</a></li>
				</ul>
			 </div>
		</div>

	

		<?php echo $__env->yieldContent('content'); ?>

		

		<div id="s-container2">
			<div id="wrap">
				<div class="post-footer">
					<p>©<?php echo e(date('Y')); ?> afribeats®. All Rights Reserved. <a href="#">Careers</a>  |  <a href="/policy-policy">Privacy Policy</a>  |  <a href="/terms-of-service">Terms & Conditions</a>. Designed by <a href="https://www.dientweb.net" target="_blank">DientWeb</a></p>
				</div>
			</div>
		</div>

		<script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
		<?php echo $__env->yieldContent('scripts'); ?>
	
	</body>
</html>
<?php /**PATH C:\xampp\htdocs\fanshub\resources\views/layouts/landing.blade.php ENDPATH**/ ?>