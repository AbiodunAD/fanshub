

<?php $__env->startSection('title'); ?>
 Admin Dashboard - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <h1>Welcome, Admin <?php echo e($user->first_name); ?></h1>

 <div class="dash-box">
    <div class="dash-box-left">
        <p>Fans Count</p>
        <p class="big-data"><?php echo e($users); ?></p>
        <div class="btn-grey"><a href="<?php echo e(route('fans.list')); ?>">Manage Fans</a></div>
    </div>

    <div class="dash-box-right">
        <p>Postcards Count</p>
        <p class="big-data"><?php echo e($postcards); ?></p>
        <div class="btn-grey"><a href="<?php echo e(route('postcards')); ?>">View Postcards</a></div>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>