<form method="POST" action="<?php echo e(route('create.postcards')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div>
        <textarea id="post" class="scroll" style="resize: none" name="post" placeholder="Share a post"></textarea>
        
        <div class="post-media">
            <div class="image-upload">
                <input type="file" name="postimage" class="postimage" title="upload an image" />
            </div>
            <div class="video-upload">
                <input type="file" name="postvideo" class="postvideo" title="upload a video" />
            </div>
        </div>

        <div class="photos" style="">

        </div>

        <button type="submit">Share</button>
        <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
    </div> 
</form> 



<?php $__env->startPush('scripts'); ?>
$(document).ready(function(){
    <script>
        alert('hello wordd');
        $('.postimage').change(function(event){
            var loadFile = function(event){
                var src = URL.createObjectURL(event.target.files[0]);
                $('.photos').empty().append(
                    '<img src="$(src)" width="50" />'
                );
            };
        });
    </script>
});
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/upcform.blade.php ENDPATH**/ ?>