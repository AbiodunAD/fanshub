

<?php $__env->startSection('title'); ?>
 Postcards - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 
<?php echo $__env->make('includes.message-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="postcard">
    <div class="postcard">
        <form method="POST" action="<?php echo e(route('create.postcard')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div>
                <textarea id="post" class="scroll" style="resize: none" name="post" placeholder="Share a post"></textarea>
                
                <div class="image-upload">
                    <label for="file-input"><img src="<?php echo e(asset('img/image-icon.png')); ?>"/></label>
                    <input type="file" name="postimage"/>
                </div>

                <button type="submit">Share</button>
                <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
            </div> 
        </form>  
    </div>
</div>

<?php $__currentLoopData = $postcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postcard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
<div id="postfeed">
    <a href="<?php echo e(route('fansprofile', $postcard->user->id)); ?>">
    <div id="postprofile">
        <div class="ppimg"><img src="<?php echo e($postcard->user->profilephoto ? asset( 'storage/media/' . $postcard->user->profilephoto ) : asset( 'img/iuser.png' )); ?>"></div>
        <div class="ppdetail">
            <p class="ppu-name"><?php echo e($postcard->user->first_name); ?> <?php echo e($postcard->user->last_name); ?></p>
            <p class="ppu-aliase"><?php echo e($postcard->user->profession); ?></p>
        </div>
    </div>
    </a>
    <div id="postshared">
        <div class="mainpost">
            <p><?php echo e($postcard->post); ?></p>
            <p><img src="<?php echo e($postcard->postimage ? asset( 'storage/media/' . $postcard->postimage ) : ''); ?>"></p>
            
            
        </div>
        <div class="mp-icons">
            <div class="mpi-c" data-bs-toggle="modal" data-bs-target="#postcardcomments<?php echo e($postcard->id); ?>" data-id="<?php echo e($postcard->id); ?>" id="postcardComment"><a href="#"><span><img src="<?php echo e(asset('img/comment-icon.png')); ?>"></span> <span class="ic-tx">
                <?php echo e($postcard->comments()->count()); ?>    
            </span></a></div>
            <div class="mpi-l" id="like"><span><img src="<?php echo e(asset('img/like.png')); ?>"></span> <span class="ic-tx">20</span></div>
            <?php if(Auth::user() == $postcard->user): ?>
            <div class="mpi-e" data-bs-toggle="modal" data-bs-target="#editpostcard<?php echo e($postcard->id); ?>" data-id="<?php echo e($postcard->id); ?>" id="editPostcard"><a href="#"><span><img src="<?php echo e(asset('img/edit-icon.png')); ?>"></span> <span class="ic-tx">Edit</span></a></div>
            <div class="mpi-d"><span><a href="<?php echo e(route('delete.postcard', ['postcard_id' => $postcard->id])); ?>"><img src="<?php echo e(asset('img/trash-icon.png')); ?>"></span> <span class="ic-tx">Delete</span></a></div>
            <?php endif; ?>
            <div class="mpi-date"><span><?php echo e($postcard->getTimeAgo($postcard->created_at)); ?></span></div>
        </div>
        <div class="comment-bx">
            <form method="post" action="<?php echo e(route('postcard.comment', $postcard->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="ps-tx">
                    <input type="hidden" name="postcard_id" value="<?php echo e($postcard->id); ?>" />
                    <textarea id="comment" class="scroll" style="resize: none" name="body" placeholder="add comment" required></textarea>
                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($body); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div> 
                
                <button class="ps-send"><img src="<?php echo e(asset('img/send-icon.png')); ?>"></button>
            </form>  
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal fade" id="editpostcard<?php echo e($postcard->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h3 class="modal-title fs-5" id="exampleModalLabel">Edit Post</h3>
            </div>
            <div class="modal-body postcard">
                <input type="hidden" name="postcard_id" value="">
                <form method="POST" action="<?php echo e(route('update.postcard', $postcard->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                    <div>
                        <textarea id="post" class="scroll" style="resize: none;color: #000;border: 0;min-height:150px;" name="post"><?php echo e($postcard->post); ?></textarea>
                    </div> 

                    <div class="modal-foot">
                        <div class="image-upload" style="margin: 12px 2px 0 0; cursor:pointer !important;">
                            <label for="file-input">
                                <img src="<?php echo e($postcard->postimage ? asset( 'storage/media/' . $postcard->postimage ) : asset('img/image-icon2.png')); ?>">
                            </label>
                            <input id="file-input" type="file" name="postimage" />
                        </div>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
                    </div>
                </form>  
            </div> 
        </div>
        </div>
    </div>

    <!-- Comment Modal -->
    <div class="modal fade" id="postcardcomments<?php echo e($postcard->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body postcard">
                    <div class="fullcol"><div class="modal-close" data-bs-dismiss="modal">x</div></div>
                    
                    <div class="pop-comm-left">
                        <img src="<?php echo e($postcard->user->profilephoto ? asset( 'storage/media/' . $postcard->user->profilephoto ) : asset('img/iuser.png')); ?>">
                    </div>
                    <div class="pop-comm-right">
                        <p class="oto"><span><?php echo e($postcard->user->first_name); ?> <?php echo e($postcard->user->last_name); ?></span> <span class="po-time"><?php echo e($postcard->getTimeAgo($postcard->created_at)); ?></span></p>
                        <p class="opo"><?php echo e($postcard->post); ?></p>
                    </div>
                    
                    <hr>
                    
                    
                    <?php $__currentLoopData = $postcard->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="pop-comm-right" id="po-comment">
                        <div class="pop-comm-box">
                            <div class="pop-comm-left2">
                                <img src="<?php echo e($comment->user->profilephoto ? asset( 'storage/media/' . $comment->user->profilephoto ) : asset('img/iuser.png')); ?>">
                            </div>
                            <div class="pop-comm-right">
                                <p class="oto"><span><?php echo e($comment->user->first_name); ?> <?php echo e($comment->user->last_name); ?></span> <span class="po-time"><?php echo e($comment->getTimeAgo($comment->created_at)); ?></span></p>
                                <p class="opo"><?php echo e($comment->body); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                </div> 
                <p>&nbsp;</p>
            </div>
        </div>
    </div>
    
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminpostcard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/postcard.blade.php ENDPATH**/ ?>