<div class="w3-bar w3-black">
    <button class="w3-bar-item w3-button tablink w3-red" onclick="openCity(event,'Portfolio')">Profile Information</button>
    <button class="w3-bar-item w3-button tablink" onclick="openCity(event,'Posts')">Posts Shared</button>
    
</div>
      
<div id="Portfolio" class="w3-container w3-border city">
    <h2>Bio</h2>
    <p>
        <?php if($user->bio): ?>
            <?php echo e($user->bio); ?>

        <?php else: ?>
            <span>No bio yet.</span>
        <?php endif; ?>  
    </p>

    <hr>

    <h2>Profession</h2>
    <p><?php if($user->profession): ?>
        <?php echo e($user->profession); ?>

    <?php else: ?>
        <span>No profession specified.</span>
    <?php endif; ?></p>
    <hr>
</div>

<div id="Posts" class="w3-container w3-border city" style="display:none">
    <p>&nbsp;</p>

    <?php if($postcards->isNotEmpty()): ?>
        <?php $__currentLoopData = $postcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postcard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <div id="postfeed">
            <?php if($user == $postcard->user): ?>
                <div id="postprofile">
                    <div class="ppimg"><img src="<?php echo e($postcard->user->profilephoto ? asset( 'storage/media/' . $postcard->user->profilephoto ) : asset( 'img/iuser.png' )); ?>"></div>
                    <div class="ppdetail">
                        <p class="ppu-name"><?php echo e($postcard->user->first_name); ?> <?php echo e($postcard->user->last_name); ?></p>
                        <p class="ppu-aliase"><?php echo e($postcard->user->profession); ?></p>
                    </div>
                </div>
                
                <?php echo $__env->make('includes.postshared', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
                <?php echo $__env->make('includes.edit-comment-modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    <?php else: ?>
    <p style="color:#ccc;font-size:12px;"><?php echo e($user->first_name); ?> has no posts at the moment. Visit the <a href="<?php echo e(route('postcard')); ?>">Postcard</a> section to view posts from other fans.</p>
    <?php endif; ?>

</div>


      
<?php /**PATH C:\xampp\htdocs\fanshub\resources\views/includes/fanfantabs.blade.php ENDPATH**/ ?>