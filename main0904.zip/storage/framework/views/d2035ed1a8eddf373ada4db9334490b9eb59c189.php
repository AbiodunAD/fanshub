

<?php $__env->startSection('title'); ?>
 Edit Profile - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<form method="post" action="<?php echo e(route('profile.update'), $user->id); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('patch'); ?>

            <h1>Edit Your Profile</h1>
            <div id="dashbox">
                <div class="log-form">
                    <div>
                        <label>Edit first name:</label>
                        <input id="first_name" name="first_name" type="text" value="<?php echo e($user->first_name); ?>" required autofocus autocomplete="first_name" />
                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($user->first_name); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label>Edit last name:</label>
                        <input id="last_name" name="last_name" type="text" value="<?php echo e($user->last_name); ?>" required autofocus autocomplete="first_name" />
                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($user->last_name); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label>Slect your profession:</label>
                        <select name="profession" value="<?php echo e($user->profession); ?>" placeholder="Select Profession:">
                            <option>Select</option>
                            <option>Artist</option>
                            <option>Musician</option>
                            <option>Creator</option>
                            <option>Promoter</option>
                            <option>Photographer</option>
                            <option>Video Maker</option>
                            <option>Dancer</option>
                            <option>Producer</option>
                            <option>Location Manager</option>
                            <option>Dress Stylist</option>
                            <option>Nail Artiste</option>
                            <option>Hair Stylist</option>
                            <option>Artiste Manager</option>
                            <option>Studio Owner</option>
                            <option>Songwriter</option>
                            <option>Journalist</option>
                            <option>Radio DJ</option>
                            <option>Event DJ</option>
                            <option>TV Programmer</option>
                            <option>Master of Ceremony</option>
                            <option>Entertainer</option>
                            <option>Influencer</option>
                            <option>Others</option>
                        </select>
                        <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($user->profession); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label>Change profile image:</label>
                        <input name="profilephoto" type="file" value="<?php echo e($user->profilephoto); ?>">
                        <?php $__errorArgs = ['profilephoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($user->profilephoto); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label>Change profile banner:</label>
                        <input name="profilebanner" type="file" value="<?php echo e($user->profilebanner); ?>">
                        <?php $__errorArgs = ['profilebanner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($user->profilebanner); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <label>Edit your bio:</label>
                        <textarea id="bio" name="bio" placeholder="Your bio:" placeholder="Your bio:"><?php echo e($user->bio); ?></textarea>
                        <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($user->bio); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button type="submit">Save Profile</button>           
                    <button><a href="<?php echo e(route('userDashboard')); ?>">Cancel</a></button>
                </div>
            </div>

            <h1>&nbsp;</h1>
            <h3>Edit Your Email</h3>
            <div id="dashbox">
                <div class="log-form">
                    <div>
                        <label>Change your email:</label>
                        <input id="email" name="email" type="email" value="<?php echo e($user->email); ?>" required autocomplete="email" />
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($user->email); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <p class="tiny-note">The above email (your current emaial address) is used for login purpose. If you change it, we will send you a confirmation email at your new address. The new email address will not become active untill it is confirmed through the link sent to it.</p>
                    <button type="submit">Change Email</button>           
                    <button><a href="<?php echo e(route('userDashboard')); ?>">Cancel</a></button>
                </div>
            </div>

            <h1>&nbsp;</h1>
            <h3>Edit Your Password</h3>
            <div id="dashbox">
                <div class="log-form">
                    <div>
                        <label class="form-control-label">Current Password</label>
                        <input name="password" type="password" class="form-control">
                    
                        <label class="form-control-label">New Password</label>
                        <input name="new_password" type="password" class="form-control">
                    
                        <label class="form-control-label">New Password Confirmation</label>
                        <input name="new_password_confirmation" type="password" class="form-control">
                    </div>
                    <button type="submit">Change Password</button>           
                    <button><a href="<?php echo e(route('userDashboard')); ?>">Cancel</a></button>
                </div>
            </div>
         
            
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fans', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/fans/profile-edit.blade.php ENDPATH**/ ?>