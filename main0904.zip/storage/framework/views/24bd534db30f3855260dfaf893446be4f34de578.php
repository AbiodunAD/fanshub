

<?php $__env->startSection('title'); ?>
 Edit Profile - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <h1>Edit Your Profile</h1>

 <div id="dashbox">
    <div class="log-form">

        <form method="post" action="<?php echo e(route('adminprofile.update'), $user->id); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>

            <div>
                <label>Edit first name:</label>
                <input id="first_name" name="first_name" type="text" value="<?php echo e($user->first_name); ?>" required autofocus autocomplete="first_name" />
                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($user->first_name); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label>Edit last name:</label>
                <input id="last_name" name="last_name" type="text" value="<?php echo e($user->last_name); ?>" required autofocus autocomplete="first_name" />
                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($user->last_name); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div>
                <label>Slect your profession:</label>
                <select name="profession" value="<?php echo e($user->profession); ?>" placeholder="Select Profession:">
                    <option>Artist</option>
                    <option>Musician</option>
                    <option>Creator</option>
                    <option>Promoter</option>
                    <option>Photographer</option>
                    <option>Video Maker</option>
                    <option>Dancer</option>
                    <option>Producer</option>
                    <option>Location Manager</option>
                    <option>Dress Stylist</option>
                    <option>Nail Artiste</option>
                    <option>Hair Stylist</option>
                    <option>Artiste Manager</option>
                    <option>Studio Owner</option>
                    <option>Songwriter</option>
                    <option>Journalist</option>
                    <option>Radio DJ</option>
                    <option>Event DJ</option>
                    <option>TV Programmer</option>
                    <option>Master of Ceremony</option>
                    <option>Entertainer</option>
                    <option>Influencer</option>
                    <option>Others</option>
                </select>
                <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($user->profession); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div>
                <label>Change profile image:</label>
                <input name="profilephoto" type="file" value="<?php echo e($user->profilephoto); ?>">
                <?php $__errorArgs = ['profilephoto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($user->profilephoto); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>


            <div>
                <label>Change profile banner:</label>
                <input name="profilebanner" type="file" value="<?php echo e($user->profilebanner); ?>">
                <?php $__errorArgs = ['profilebanner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($user->profilebanner); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label>Edit your bio:</label>
                <textarea id="bio" name="bio" placeholder="Your bio:" placeholder="Your bio:"><?php echo e($user->bio); ?></textarea>
                <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($user->bio); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label>Change your email:</label>
                <input id="email" name="email" type="email" value="<?php echo e($user->email); ?>" required autocomplete="email" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($user->email); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="flex items-center gap-4">
                <button type="submit">Save Profile</button>
            </div>
            <button><a href="<?php echo e(route('adminDashboard')); ?>">Cancel</a></button>
        </form>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/profile-edit.blade.php ENDPATH**/ ?>