<div id="postshared" data-post="<?php echo e($postcard->id); ?>" class="card">
    <div class="mainpost">
        <p><?php echo e($postcard->post); ?></p>
        <div class="po-mdi">
            <?php if($postcard->postvideo): ?>
                <p>
                    <video width="100%" height="240" controls>
                        <source src="<?php echo e($postcard->postvideo ? asset( 'storage/media/' . $postcard->postvideo ) : ''); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                    </video>
                </p>

             <?php elseif($postcard->postimage): ?>
                <p><img src="<?php echo e($postcard->postimage ? asset( 'storage/media/' . $postcard->postimage ) : ''); ?>"></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="mp-icons">
        
        <?php if(Auth::user()): ?>
        <div class="mpi-c" data-bs-toggle="modal" data-bs-target="#postcardcomments<?php echo e($postcard->id); ?>" data-id="<?php echo e($postcard->id); ?>" id="postcardComment">
            <a href="#"><span class="ic-tx"><i class="fa-regular fa-message <?php echo e(auth()->check() && $postcard->comments->contains('user_id',auth()->id()) ? 'redHeart' : 'greycolor'); ?>"></i> <div class="ccount"><?php echo e($postcard->comments()->count()); ?></div></span></a>
        </div>
        <?php else: ?>
        <div class="mpi-c" data-bs-toggle="modal" data-bs-target="#postcardcomments<?php echo e($postcard->id); ?>" data-id="<?php echo e($postcard->id); ?>" id="postcardComment">
            <a href="#"><span class="ic-tx"><i class="fa-regular fa-message"></i> <div class="ccount"><?php echo e($postcard->comments()->count()); ?></div></span></a>
        </div>
        <?php endif; ?>


        
        <div class="mpi-l" class="" >
            <?php if(Auth::user()): ?>
            <span class="ic-tx"> 
                <form id="liking" method="post" action="<?php echo e(route('postcard.like', $postcard->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="postcard_id" class="postcard_id" value="<?php echo e($postcard->id); ?>" />
                    <input type="hidden" namae="user_id" class="user_id" value="<?php echo e(Auth::user()->id); ?>" />
                    <input type="hidden" name="like" class="like" value="1" />
                    <button class="lk-send" id="like"><i class="fa fa-thumbs-up <?php echo e(auth()->check() && $postcard->likes->contains('user_id',auth()->id()) ? 'redHeart' : 'greycolor'); ?>"></i></button>
                    <div class="ccount"><?php echo e($postcard->likes()->where('like' , 1)->count() ?: '0'); ?></div>
                </form>
            </span>
            <?php else: ?>
            <span class="ic-tx"> 
                <button class="lk-send" id="like"><i class="fa fa-thumbs-up"></i></button>
                <div class="ccount"><?php echo e($postcard->likes()->where('like' , 1)->count() ?: '0'); ?></div>
            </span>
            <?php endif; ?>
        </div>

        
        
        <?php if(Auth::user() == $postcard->user): ?>
            <div class="mpi-e" data-bs-toggle="modal" data-bs-target="#editpostcard<?php echo e($postcard->id); ?>" data-id="<?php echo e($postcard->id); ?>" id="editPostcard">
                <a href="#"><span class="ic-tx"><i class="fa-regular fa-edit"></i></span></a>
            </div>
            <div class="mpi-d">
                <span><a href="<?php echo e(route('delete.postcard', ['postcard_id' => $postcard->id])); ?>"><span class="ic-tx"><i class="fa-regular fa-trash-o"></i></span></a></span>
            </div>
        <?php endif; ?>
        
        
        <div class="mpi-s" data-bs-toggle="modal" data-bs-target="#postcardshare<?php echo e($postcard->id); ?>" data-id="<?php echo e($postcard->id); ?>" id="sharePostcard">            
            <span class="ic-tx"><a href="#"><span><img src="<?php echo e(asset('img/share-icon.png')); ?>"></span></a></span>
        </div>

        
        <div class="mpi-date"><span><?php echo e($postcard->getTimeAgo($postcard->created_at)); ?></span></div>
       
    </div>
    

    
    <?php if(Auth::user()): ?>
        <div class="comment-bx">
            <form method="post" action="<?php echo e(route('postcard.comment', $postcard->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="ps-tx">
                    <input type="hidden" name="postcard_id" value="<?php echo e($postcard->id); ?>" />
                    <textarea id="comment" class="scroll" style="resize: none" name="body" placeholder="add comment" required></textarea>
                    <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($body); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div> 
                
                <button class="ps-send"><i class="fa-regular fa-send-o"></i> </button>
            </form>  
        </div>
    <?php endif; ?>
</div>





<?php /**PATH C:\xampp\htdocs\fanshub\resources\views/includes/pscard.blade.php ENDPATH**/ ?>