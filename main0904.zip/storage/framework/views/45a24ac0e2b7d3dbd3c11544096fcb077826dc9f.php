

<?php $__env->startSection('title'); ?>
 Postcards - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 
<?php echo $__env->make('includes.message-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="postcard">
    <div class="postcard">
        <?php echo $__env->make('includes.pcform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </div>
</div>

<?php $__currentLoopData = $postcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postcard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
<div id="postfeed">
    <a href="<?php echo e(route('fansprofile', $postcard->user->first_name)); ?>">
    <div id="postprofile">
        <div class="ppimg"><img src="<?php echo e($postcard->user->profilephoto ? asset( 'storage/media/' . $postcard->user->profilephoto ) : asset( 'img/iuser.png' )); ?>"></div>
        <div class="ppdetail">
            <p class="ppu-name"><?php echo e($postcard->user->first_name); ?> <?php echo e($postcard->user->last_name); ?></p>
            <p class="ppu-aliase"><?php echo e($postcard->user->profession); ?></p>
        </div>
    </div>
    </a>

    <?php echo $__env->make('includes.pscard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.modalcard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminpostcard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/postcards.blade.php ENDPATH**/ ?>