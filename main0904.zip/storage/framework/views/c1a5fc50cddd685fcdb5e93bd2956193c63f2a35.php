<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    
    
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('stylesheet.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('boostrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Scripts -->
    <script src="https://kit.fontawesome.com/22d44955ad.js" crossorigin="anonymous"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
</head>

<body class="dashboard userboard adminpop">
    <div id="header-section">
        <div id="wrap">
            
            <div class="header-logo">
                <a href="<?php echo e(route('welcome')); ?>"><img src="<?php echo e(asset('img/logo2.png')); ?>"></a>
            </div>
            <div class="header-components">
                <form action="/admin-dashboard/postcards">
                    <div class="header-search" id="mob-search">
                        <button type="submit" class=""><img class="hide8" src="<?php echo e(asset('img/si.png')); ?>"><img class="show8" src="<?php echo e(asset('img/si2.png')); ?>"></button>
                        <input type="text" name="search" class="" placeholder="Search..." />
                    </div>
                </form>

                <div class="burger show-on-eight">
                    <a href="#" onclick="hamBurger()">
                        <img src="<?php echo e(asset('img/hamburger.png')); ?>">
                    </a>

                    <div id="sub-men">
                        <li><a href="<?php echo e(route('adminDashboard')); ?>" class="<?php echo e(Route::currentRouteName() == 'adminDashboard' ? 'activ' : ''); ?>">MyFansHub</a></li>
                        <li><a href="<?php echo e(route('fans.list')); ?>" class="<?php echo e(Route::currentRouteName() == 'fans.list' ? 'activ' : ''); ?>">Fans Directory</a></li>
                        <li><a href="<?php echo e(route('postcards')); ?>" class="<?php echo e(Route::currentRouteName() == 'postcards' ? 'activ' : ''); ?>">Postcards</a></li>
                        <li><a href="<?php echo e(route('pages.all')); ?>" class="<?php echo e(Route::currentRouteName() == 'pages.all' ? 'activ' : ''); ?>">Pages</a></li>
                        
                    </div>
                </div>

                <div class="search-small show-on-eight">
                    <a href="#" onclick="moSearch()">
                        <img src="<?php echo e(asset('img/isearch.png')); ?>">
                    </a>
                </div>

                <div class="user-welcome">
                    <a href="#" onclick="myFunction()">
                        <div class="uw-name">Hi Admin <?php echo e(Auth::user()->first_name); ?></div>
                        <div class="uw-image" style="background-image:url('<?php echo e(Auth::user()->profilephoto ? asset( 'storage/media/' . Auth::user()->profilephoto ) : asset('img/iuser.png')); ?>');background-size: cover;
                            background-repeat: no-repeat; ">
                            &nbsp;
                        </div>
                    </a>

                    <div id="uw-sub">
                        <li>
                            <a href="<?php echo e(route('adminDashboard')); ?>" class="<?php echo e(Route::currentRouteName() == 'adminDashboard' ? 'activ' : ''); ?>">
                            Admin Dashboard
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('adminprofile.edit')); ?>" class="<?php echo e(Route::currentRouteName() == 'adminprofile.edit' ? 'activ' : ''); ?>">
                            Edit Your Profile
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                               Logout
                            </a>
                    
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="s-container remove-on-mobile">

        <div id="dash-sidebar">
            <ul>
                <li><a href="<?php echo e(route('adminDashboard')); ?>" class="<?php echo e(Route::currentRouteName() == 'adminDashboard' ? 'active-dash' : ''); ?>"><span class="sb-ic"><img src="<?php echo e(asset('img/mf.png')); ?>"></span><span class="sb-tx">Dashboard</span></a></li>
                <li><a href="<?php echo e(route('fans.list')); ?>" class="<?php echo e(Route::currentRouteName() == 'fans.list' ? 'active-dash' : ''); ?>"><span class="sb-ic"><img src="<?php echo e(asset('img/fs.png')); ?>"></span><span class="sb-tx">Fans Directory</span></a></li>
                <li><a href="<?php echo e(route('postcards')); ?>" class="nav-link <?php echo e(Route::currentRouteName() == 'postcards' ? 'active-dash' : ''); ?>"><span class="sb-ic2"><img src="<?php echo e(asset('img/pc.png')); ?>"></span><span class="sb-tx">Postcards</span></a></li>
                <li><a href="<?php echo e(route('pages.all')); ?>" class="nav-link <?php echo e(Route::currentRouteName() == 'pages.all' ? 'active-dash' : ''); ?>"><span class="sb-ic"><img src="<?php echo e(asset('img/ev.png')); ?>"></span><span class="sb-tx">Manage Pages</span></a></li>
                
            </ul>

            <div class="dash-copy">
                <p><a href="#">Privacy Policy</a> | <a href="#">Terms & Conditions</a>.  © afribeats®. All Rights Reserved. Designed by <a href="#">DientWeb</a></p>
            </div>
        </div>

        <div id="dash-main">
            <?php echo $__env->yieldContent('content'); ?>

            <div id="dash-foot">					
                <h3>MEMBERSHIP IS FREE</h3>
                <p style="margin-bottom: 0;">Supported only by Donations & Sponsorship</p>
                <p>Donate to, or sponsor afribeats "Talent Support Revolution" today and get a STAR up on the success podium</p>
                <p class="btn-grey"><a href="https://www.paypal.com/donate/?hosted_button_id=42UQ84BW4GWVG" target="_blank">Donate</a></p>

                <ul>
                    <li><a href="<?php echo e(route('welcome')); ?>">Home</a></li>
                    <li><a href="/about-us">About Us</a></li>
                    
                    <li><a href="<?php echo e(route('contact')); ?>">Contacts</a></li>
                </ul>
            </div>

            <div class="post-footer show-on-eight foot-credit">
                <p>©2022 afribeats®. All Rights Reserved. <a href="careers.html">Careers</a>  |  <a href="policy.html">Privacy Policy</a>  |  <a href="terms.html">Terms & Conditions</a>.  Designed by <a href="https://www.dientweb.net" target="_blank">DientWeb</a></p>
            </div>
        </div>

    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-oP6HI9z1XaZNBrJURtCoUT5SUnxFr8s3BzRl+cbzUq8=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/layouts/adminpostcard.blade.php ENDPATH**/ ?>