

<?php $__env->startSection('title'); ?>
 Creat New Page - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1>Creat a New Page</h1>
<div id="dashbox">
    <div class="log-form">

        <form method="post" action="<?php echo e(route('page.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div>
                <label>Enter Page Slug:</label>
                <input type="text" name="slug" placeholder="Page Slug:" required autofocus />
            </div>

            <div>
                <label>Enter Page Title:</label>
                <input type="text" name="title" placeholder="Page Title:" required autofocus />
            </div>
           
            <div>
                <label style="margin-bottom:20px;">Enter Page Content:</label>
                <textarea id="summernote" name="body"></textarea>
            </div>

            <div>
                <label>Enter Page Excerpt:</label>
                <input type="text" name="excerpt" placeholder="Enter Excerpt:" required autofocus />
            </div>

            <p>&nbsp;</p>
            <div class="flex items-center gap-4">
                <button type="submit">Publish</button>
            </div>
            <button><a href="<?php echo e(route('pages.all')); ?>">Cancel</a></button>
        </form>
        
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/createpage.blade.php ENDPATH**/ ?>