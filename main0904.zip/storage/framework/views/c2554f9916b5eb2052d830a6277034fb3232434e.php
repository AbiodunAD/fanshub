

<?php $__env->startSection('title'); ?>
 Postcards - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('includes.message-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="postcard">
        <div class="postcard">
            

            <?php echo $__env->make('upcform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
    
    <?php $__currentLoopData = $postcards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postcard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
    <div id="postfeed">
        <a href="<?php echo e(route('fanprofile', $postcard->user->first_name)); ?>">
        <div id="postprofile">
            <div class="ppimg">
                <img src="<?php echo e($postcard->user->profilephoto ? asset( 'storage/media/' . $postcard->user->profilephoto ) : asset( 'img/iuser.png' )); ?>">
            </div>
            <div class="ppdetail">
                <p class="ppu-name"><?php echo e($postcard->user->first_name); ?> <?php echo e($postcard->user->last_name); ?></p>
                <p class="ppu-aliase"><?php echo e($postcard->user->profession); ?></p>
            </div>
        </div>
        </a>

        <?php echo $__env->make('includes.pscard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('includes.modalcard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
    $(document).ready(function(){

        // var postcard_id = $('.add_like').val();
        // var likescount = "<?php echo e($postcard->likes()->count()); ?>";
        function fetchlikes(){
            $.ajax({
                url: "/myfanshub/postcard",
                dataType: "text",
                success: function(response){
                    $('#newcount').html(jQuery(response).find('#numberOfLikes').html()); 
                }
            });
        }

        
        $(document).on('click', '.add_like', function(e){
            e.preventDefault();
            //console.log("hello world")
            
            var postcard_id = $(this).val();
            // console.log(postcard_id);

            var data = {
				'postcard_id': $(this).val(),
				'user_id': $('.user_id').val(),
				'like': 1,
			}
			// console.log(data);

            $.ajaxSetup({
			    headers: {
			        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			    }
			});

            $.ajax({
                type: "POST",
                url: "/myfanshub/postcard/"+postcard_id+"/like",
                data: data,
                dataType: "json",
                success: function(response){
                   console.log(response);
                //    var newlk = jQuery(response).find(response.likes);
                //    $('#newcount').html(newlk);
                //    $('#newcount').html(jQuery(response).find(response.likes).val());
                //    $('#newcount').html(jQuery(response.likes).val());
                //    console.log("#newcount").html();
                //    fetchlikes();
                }
            });

            // .done(function(response) {
            //     $('#numberOfLikes').html(jQuery(response.likes).val()));
            // });
        });

    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.postcard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/postcard.blade.php ENDPATH**/ ?>