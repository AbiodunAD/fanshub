

<?php $__env->startSection('title'); ?>
 Edit <?php echo e($page->title); ?> - afribeats®
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
 <h1>Edit <?php echo e($page->title); ?></h1>

    <div id="dashbox">
        <div class="log-form">

            <form method="post" action="<?php echo e(route('page.update', $page->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>

                <div>
                    <label>Edit Page Title:</label>
                    <input type="text" name="title" value="<?php echo e($page->title); ?>" required autofocus />
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($page->title); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label>Edit Page Slug:</label>
                    <input type="text" name="slug" value="<?php echo e($page->slug); ?>" required autofocus />
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($page->slug); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($page->body); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label style="margin-bottom:20px;">Edit Page Content:</label>
                    <textarea id="summernote" name="body"><?php echo e($page->body); ?></textarea>
                </div>

                <div>
                    <label>Edit Page Excerpt:</label>
                    <input type="text" name="excerpt" value="<?php echo e($page->excerpt); ?>" required autofocus />
                    <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($page->excerpt); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <p>&nbsp;</p>
                <div class="flex items-center gap-4">
                    <button type="submit">Publish</button>
                </div>
                <button><a href="<?php echo e(route('pages.all')); ?>">Cancel</a></button>
            </form>
    
            
        </div>
    </div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/edit-page.blade.php ENDPATH**/ ?>