<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
		<meta name="viewport" content="width=device-width">
		<title><?php echo e(config('app.name', 'afribeats')); ?></title>
		<link rel="icon" type="image/png" href="<?php echo e(asset('img/favicon.png')); ?>" />
		<link rel="stylesheet" type="text/css" href="<?php echo e(asset('stylesheet.css')); ?>">

		<!-- Scripts -->
		<script type="text/javascript" src="<?php echo e(asset('js/main.js')); ?>"></script>
	</head>

    <body>
		<div id="header-section">
			<div id="wrap">
				
					<div class="header-logo">
						<a href="<?php echo e(route('welcome')); ?>"><img src="<?php echo e(asset('img/logo2.png')); ?>"></a>
					</div>
					<div class="header-menu header">
						<div class="header">
							<ul class="menu">
								<li><a href="<?php echo e(route('welcome')); ?>">Home</a></li>
								<li><a href="#">Support</a></li>
								<li><a href="#">Livechat</a></li>
								<li><a href="#">Contacts</a></li>
								<?php if(auth()->guard()->guest()): ?>
									<?php if(Route::has('login')): ?>
										<li class="nav-item">
											<a class="nav-link" href="<?php echo e(route('login')); ?>">Signup/Login</a>
										</li>
									<?php endif; ?>

																	
									<?php else: ?>
										<li class="nav-item">
											<a class="nav-link" href="<?php echo e(route('home')); ?>">My Account</a>
										</li>
								<?php endif; ?>    
                            </ul>
						</div>
					</div>


					<?php if(auth()->guard()->guest()): ?>
					<?php if(Route::has('login')): ?>
					<div class="show-on-small" id="small-log">
						<a href="<?php echo e(route('login')); ?>"><img src="<?php echo e(asset('img/iuser.png')); ?>"></a>
					</div>
					<?php endif; ?>

					<?php else: ?>
						
					<div class="show-on-small" id="small-log" style="background-image:url('<?php echo e(Auth::user()->profilephoto ? asset( 'storage/media/' . $user->profilephoto ) : asset('img/iuser.png')); ?>');background-size: cover;
						background-repeat: no-repeat; ">
						<a href="<?php echo e(route('userDashboard')); ?>">&nbsp;</a>
					</div>					
					<?php endif; ?>


				
			</div>
		</div>

		<div id="foo-bar">
			<div id="wrap">
			  	<ul class="menu">
					<li><a href="<?php echo e(route('welcome')); ?>">
						<span><img src="<?php echo e(asset('img/ihome.png')); ?>"></span>
						<span>Home</span>
					</a></li>
					<li><a href="#">
						<span><img src="<?php echo e(asset('img/isupport.png')); ?>"></span>
						<span>Support</span>
					</a></li>
					<li><a href="#">
						<span><img src="<?php echo e(asset('img/ichat.png')); ?>"></span>
						<span>Livechat</span>
					</a></li>
					<li><a href="#">
						<span><img src="<?php echo e(asset('img/icontact.png')); ?>"></span>
						<span>Contacts</span>
					</a></li>
				</ul>
			 </div>
		</div>

		<div id="s-container remove-on-mobile">&nbsp;</div>

		<?php echo $__env->yieldContent('content'); ?>

		<div id="s-container">&nbsp;</div>

		<div id="s-container">
			<div id="wrap">
				<div class="footer">
					<h3>The best things in life are without charge! They’ll always be FREE!</h3>
					<p>Donate to Support AMFW’s Free-to-Participate, Marathon Search for AFRICAN MUSIC & DANCE TALENTS Across Africa and Mobilize One Billion FANS for afribeats® Worldwide.</p>
					<p class="btn-grey"><a href="#">Donate</a></p>
				</div>

				<div class="post-footer">
					<p>© afribeats®. All Rights Reserved. <a href="#">Careers</a>  |  <a href="#">Privacy Policy</a>  |  <a href="#">Terms & Conditions</a>.  Designed by <a href="https://www.dientweb.net" target="_blank">DientWeb</a></p>
				</div>
			</div>
		</div>


	</body>
</html>
<?php /**PATH C:\xampp\htdocs\fanshub\resources\views/layouts/master.blade.php ENDPATH**/ ?>