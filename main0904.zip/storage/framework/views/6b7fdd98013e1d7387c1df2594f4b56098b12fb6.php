

<?php $__env->startSection('title'); ?>
 <?php echo e($user->first_name); ?> Profile - afribeats®
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="user-profile-img">
    <div class="user-pi-large" style="background-image: url('<?php echo e($user->profilebanner ? asset( 'storage/media/' . $user->profilebanner ) : asset('img/pban.png')); ?>'); background-size: cover;
      background-repeat: no-repeat;">
      &nbsp;
    </div>
    <div class="user-pi-plus">
        <div class="up-image" style="background-image:url('<?php echo e($user->profilephoto ? asset( 'storage/media/' . $user->profilephoto ) : asset('img/iuser.png')); ?>');background-size: cover;
          background-repeat: no-repeat; ">
          &nbsp;
        </div>
        <div class="up-name"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></div>
        <div class="up-pro">
          <?php if($user->profession): ?>
              <?php echo e($user->profession); ?>

          <?php else: ?>
              <span>-</span>
          <?php endif; ?>  
        </div>
    </div>
</div>

<div id="tab-area">
    <div class="w3-container">
     
        <?php echo $__env->make('includes.tabscard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminpostcard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fanshub\resources\views/admin/fanprofile.blade.php ENDPATH**/ ?>